import abc
import requests
import json


class Delete:
    @abc.abstractmethod
    def __init__(self):
        raise NotImplementedError

